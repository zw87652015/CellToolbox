#include <mex.h>
#include "mzcam.h"

#define PARAM_CLOSE        0x0000
#define PARAM_SNAP         0x0001
#define PARAM_AEXP         0x0002
#define PARAM_EXPTIME      0x0003
#define PARAM_WBONCE       0x0004
#define PARAM_TEMP         0x0005
#define PARAM_TINT         0x0006
#define PARAM_HUE          0x0007
#define PARAM_SATURATION   0x0008
#define PARAM_BRIGHTNESS   0x0009
#define PARAM_CONTRAST     0x000a
#define PARAM_GAMMA        0x000b
#define PARAM_WBDFT        0x000c
#define PARAM_COLORDFT     0x000d
#define PARAM_BBONCE       0x000e
#define PARAM_ROFFSET      0x000f
#define PARAM_GOFFSET      0x0010
#define PARAM_BOFFSET      0x0011
#define PARAM_BBDFT        0x0012
#define PARAM_CHROME       0x0013
#define PARAM_FFCONCE      0x0014
#define PARAM_DFCONCE      0x0015
#define PARAM_POWERSUPPLY  0x0016
#define PARAM_VFLIP        0x0017
#define PARAM_HFLIP        0x0018
#define PARAM_ROTATE       0x0019
#define PARAM_SHARPENING   0x001a
#define PARAM_BITDEPTH     0x001b
#define PARAM_BINNING      0x001c
#define PARAM_LINEAR       0x001d
#define PARAM_CURVE        0x001e

static unsigned char* g_imgData = nullptr;
static HMzcam g_hCam = nullptr;
static int g_captureIndex = 0;

static void saveDataAsBmp(const void* pData, const BITMAPINFOHEADER* pHeader)
{
    char str[256];
    sprintf(str, "%04d.bmp", ++g_captureIndex);
    FILE* fp = fopen(str, "wb");
    if (fp)
    {
        BITMAPFILEHEADER fh = { 0 };
        fh.bfType = 'M' << 8 | 'B';
        fh.bfSize = sizeof(fh) + sizeof(BITMAPINFOHEADER) + pHeader->biSizeImage;
        fh.bfOffBits = sizeof(fh) + sizeof(BITMAPINFOHEADER);
        fwrite(&fh, sizeof(fh), 1, fp);
        fwrite(pHeader, sizeof(BITMAPINFOHEADER), 1, fp);
        fwrite(pData, pHeader->biSizeImage, 1, fp);
        fclose(fp);
    }
}

static void DataCallback(const void* pData, const BITMAPINFOHEADER* pHeader, BOOL bSnap, void* pCallbackCtx)
{
    if (bSnap)
        saveDataAsBmp(pData, pHeader);
    else if (g_imgData)
    {
        if (TDIBWIDTHBYTES(pHeader->biWidth * 24) == pHeader->biWidth * 3)          // row pitch
            memcpy(g_imgData, pData, pHeader->biWidth * pHeader->biHeight * 3);
        else
        {
            unsigned char* pTmp = (unsigned char*)pData;
            for (int i = 0; i < pHeader->biHeight; ++i)
                memcpy(g_imgData + pHeader->biWidth * 3 * i, pTmp + TDIBWIDTHBYTES(pHeader->biWidth * 24) * i, pHeader->biWidth * 3);
        }
    }
}

static void EnumCameras(mxArray* plhs[])
{
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    double* y = mxGetPr(plhs[0]);
    MzcamDeviceV2 ti[MZCAM_MAX];
    int ret = Mzcam_EnumV2(ti);
    *y = ret;
    if (ret)
    {
        mwSize dims[2] = {1, ret};
        const char* field_names[] = {"name", "id"};
        plhs[1] = mxCreateStructArray(2, dims, 2, field_names);
        int name_field = mxGetFieldNumber(plhs[1], "name");
        int id_field = mxGetFieldNumber(plhs[1], "id");
        for (int i = 0; i < ret; i++)
        {
            char name[64] = { 0 }, id[64] = { 0 };
            wcstombs(name, ti[i].displayname, sizeof(name));
            wcstombs(id, ti[i].id, sizeof(id));
            mxSetFieldByNumber(plhs[1], i, name_field, mxCreateString(name));
            mxSetFieldByNumber(plhs[1], i, id_field, mxCreateString(id));
        }
    }
    else
    {
        plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
    }
}

static int Init(unsigned nRes, unsigned short nSpeed, char* ID)
{
    wchar_t id[64] = { 0 };
    if (ID && ID[0])
        mbstowcs(id, ID, sizeof(id));
    g_hCam = Mzcam_Open(id);
    if (g_hCam)
    {
        Mzcam_put_Speed(g_hCam, nSpeed);
        Mzcam_put_eSize(g_hCam, nRes);
        Mzcam_StartPushMode(g_hCam, DataCallback, nullptr);
        return S_OK;
    }
    return S_FALSE;
}

static void ConstParams(mxArray* plhs[])
{
    const char* field_names[] = {"MZCAM_TEMP_DEF", "MZCAM_TEMP_MIN", "MZCAM_TEMP_MAX", "MZCAM_TINT_DEF", "MZCAM_TINT_MIN",
                                "MZCAM_TINT_MAX", "MZCAM_HUE_DEF", "MZCAM_HUE_MIN", "MZCAM_HUE_MAX", "MZCAM_SATURATION_DEF", "MZCAM_SATURATION_MIN",
                                "MZCAM_SATURATION_MAX", "MZCAM_BRIGHTNESS_DEF", "MZCAM_BRIGHTNESS_MIN", "MZCAM_BRIGHTNESS_MAX", "MZCAM_CONTRAST_DEF",
                                "MZCAM_CONTRAST_MIN", "MZCAM_CONTRAST_MAX", "MZCAM_GAMMA_DEF", "MZCAM_GAMMA_MIN", "MZCAM_GAMMA_MAX", "MZCAM_AETARGET_DEF",
                                "MZCAM_AETARGET_MIN", "MZCAM_AETARGET_MAX", "MZCAM_WBGAIN_DEF", "MZCAM_WBGAIN_MIN", "MZCAM_WBGAIN_MAX", "MZCAM_BLACKLEVEL_MIN",
                                "MZCAM_BLACKLEVEL8_MAX", "MZCAM_BLACKLEVEL10_MAX", "MZCAM_BLACKLEVEL12_MAX", "MZCAM_BLACKLEVEL14_MAX", "MZCAM_BLACKLEVEL16_MAX",
                                "MZCAM_SHARPENING_STRENGTH_DEF", "MZCAM_SHARPENING_STRENGTH_MIN", "MZCAM_SHARPENING_STRENGTH_MAX", "MZCAM_SHARPENING_RADIUS_DEF",
                                "MZCAM_SHARPENING_RADIUS_MIN", "MZCAM_SHARPENING_RADIUS_MAX", "MZCAM_SHARPENING_THRESHOLD_DEF", "MZCAM_SHARPENING_THRESHOLD_MIN",
                                "MZCAM_SHARPENING_THRESHOLD_MAX"};
    int MZCAM_TEMP_DEF_field, MZCAM_TEMP_MIN_field, MZCAM_TEMP_MAX_field, MZCAM_TINT_DEF_field, MZCAM_TINT_MIN_field,
                                MZCAM_TINT_MAX_field, MZCAM_HUE_DEF_field, MZCAM_HUE_MIN_field, MZCAM_HUE_MAX_field, MZCAM_SATURATION_DEF_field,
                                MZCAM_SATURATION_MIN_field,MZCAM_SATURATION_MAX_field, MZCAM_BRIGHTNESS_DEF_field, MZCAM_BRIGHTNESS_MIN_field,
                                MZCAM_BRIGHTNESS_MAX_field, MZCAM_CONTRAST_DEF_field, MZCAM_CONTRAST_MIN_field, MZCAM_CONTRAST_MAX_field,
                                MZCAM_GAMMA_DEF_field, MZCAM_GAMMA_MIN_field, MZCAM_GAMMA_MAX_field, MZCAM_AETARGET_DEF_field, MZCAM_AETARGET_MIN_field,
                                MZCAM_AETARGET_MAX_field, MZCAM_WBGAIN_DEF_field, MZCAM_WBGAIN_MIN_field, MZCAM_WBGAIN_MAX_field,
                                MZCAM_BLACKLEVEL_MIN_field, MZCAM_BLACKLEVEL8_MAX_field, MZCAM_BLACKLEVEL10_MAX_field, MZCAM_BLACKLEVEL12_MAX_field,
                                MZCAM_BLACKLEVEL14_MAX_field, MZCAM_BLACKLEVEL16_MAX_field, MZCAM_SHARPENING_STRENGTH_DEF_field, MZCAM_SHARPENING_STRENGTH_MIN_field,
                                MZCAM_SHARPENING_STRENGTH_MAX_field, MZCAM_SHARPENING_RADIUS_DEF_field, MZCAM_SHARPENING_RADIUS_MIN_field,
                                MZCAM_SHARPENING_RADIUS_MAX_field, MZCAM_SHARPENING_THRESHOLD_DEF_field, MZCAM_SHARPENING_THRESHOLD_MIN_field,
                                MZCAM_SHARPENING_THRESHOLD_MAX_field;
    plhs[3] = mxCreateStructMatrix(1, 1, 42, field_names);
    MZCAM_TEMP_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_TEMP_DEF");
    MZCAM_TEMP_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_TEMP_MIN");
    MZCAM_TEMP_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_TEMP_MAX");
    MZCAM_TINT_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_TINT_DEF");
    MZCAM_TINT_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_TINT_MIN");
    MZCAM_TINT_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_TINT_MAX");
    MZCAM_HUE_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_HUE_DEF");
    MZCAM_HUE_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_HUE_MIN");
    MZCAM_HUE_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_HUE_MAX");
    MZCAM_SATURATION_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_SATURATION_DEF");
    MZCAM_SATURATION_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_SATURATION_MIN");
    MZCAM_SATURATION_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_SATURATION_MAX");
    MZCAM_BRIGHTNESS_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_BRIGHTNESS_DEF");
    MZCAM_BRIGHTNESS_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_BRIGHTNESS_MIN");
    MZCAM_BRIGHTNESS_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_BRIGHTNESS_MAX");
    MZCAM_CONTRAST_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_CONTRAST_DEF");
    MZCAM_CONTRAST_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_CONTRAST_MIN");
    MZCAM_CONTRAST_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_CONTRAST_MAX");
    MZCAM_GAMMA_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_GAMMA_DEF");
    MZCAM_GAMMA_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_GAMMA_MIN");
    MZCAM_GAMMA_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_GAMMA_MAX");
    MZCAM_AETARGET_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_AETARGET_DEF");
    MZCAM_AETARGET_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_AETARGET_MIN");
    MZCAM_AETARGET_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_AETARGET_MAX");
    MZCAM_WBGAIN_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_WBGAIN_DEF");
    MZCAM_WBGAIN_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_WBGAIN_MIN");
    MZCAM_WBGAIN_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_WBGAIN_MAX");
    MZCAM_BLACKLEVEL_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_BLACKLEVEL_MIN");
    MZCAM_BLACKLEVEL8_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_BLACKLEVEL8_MAX");
    MZCAM_BLACKLEVEL10_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_BLACKLEVEL10_MAX");
    MZCAM_BLACKLEVEL12_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_BLACKLEVEL12_MAX");
    MZCAM_BLACKLEVEL14_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_BLACKLEVEL14_MAX");
    MZCAM_BLACKLEVEL16_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_BLACKLEVEL16_MAX");
    MZCAM_SHARPENING_STRENGTH_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_STRENGTH_DEF");
    MZCAM_SHARPENING_STRENGTH_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_STRENGTH_MIN");
    MZCAM_SHARPENING_STRENGTH_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_STRENGTH_MAX");
    MZCAM_SHARPENING_RADIUS_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_RADIUS_DEF");
    MZCAM_SHARPENING_RADIUS_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_RADIUS_MIN");
    MZCAM_SHARPENING_RADIUS_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_RADIUS_MAX");
    MZCAM_SHARPENING_THRESHOLD_DEF_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_THRESHOLD_DEF");
    MZCAM_SHARPENING_THRESHOLD_MIN_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_THRESHOLD_MIN");
    MZCAM_SHARPENING_THRESHOLD_MAX_field = mxGetFieldNumber(plhs[3], "MZCAM_SHARPENING_THRESHOLD_MAX");
    mxArray *MZCAM_TEMP_DEF_value, *MZCAM_TEMP_MIN_value, *MZCAM_TEMP_MAX_value, *MZCAM_TINT_DEF_value, *MZCAM_TINT_MIN_value,
            *MZCAM_TINT_MAX_value, *MZCAM_HUE_DEF_value, *MZCAM_HUE_MIN_value, *MZCAM_HUE_MAX_value, *MZCAM_SATURATION_DEF_value,
            *MZCAM_SATURATION_MIN_value, *MZCAM_SATURATION_MAX_value, *MZCAM_BRIGHTNESS_DEF_value, *MZCAM_BRIGHTNESS_MIN_value,
            *MZCAM_BRIGHTNESS_MAX_value, *MZCAM_CONTRAST_DEF_value, *MZCAM_CONTRAST_MIN_value, *MZCAM_CONTRAST_MAX_value,
            *MZCAM_GAMMA_DEF_value, *MZCAM_GAMMA_MIN_value, *MZCAM_GAMMA_MAX_value, *MZCAM_AETARGET_DEF_value, *MZCAM_AETARGET_MIN_value,
            *MZCAM_AETARGET_MAX_value, *MZCAM_WBGAIN_DEF_value, *MZCAM_WBGAIN_MIN_value, *MZCAM_WBGAIN_MAX_value,
            *MZCAM_BLACKLEVEL_MIN_value, *MZCAM_BLACKLEVEL8_MAX_value, *MZCAM_BLACKLEVEL10_MAX_value, *MZCAM_BLACKLEVEL12_MAX_value,
            *MZCAM_BLACKLEVEL14_MAX_value, *MZCAM_BLACKLEVEL16_MAX_value, *MZCAM_SHARPENING_STRENGTH_DEF_value, *MZCAM_SHARPENING_STRENGTH_MIN_value,
            *MZCAM_SHARPENING_STRENGTH_MAX_value, *MZCAM_SHARPENING_RADIUS_DEF_value, *MZCAM_SHARPENING_RADIUS_MIN_value,
            *MZCAM_SHARPENING_RADIUS_MAX_value, *MZCAM_SHARPENING_THRESHOLD_DEF_value, *MZCAM_SHARPENING_THRESHOLD_MIN_value,
            *MZCAM_SHARPENING_THRESHOLD_MAX_value;
    MZCAM_TEMP_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_TEMP_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_TEMP_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_TINT_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_TINT_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_TINT_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_HUE_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_HUE_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_HUE_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SATURATION_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SATURATION_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SATURATION_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BRIGHTNESS_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BRIGHTNESS_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BRIGHTNESS_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_CONTRAST_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_CONTRAST_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_CONTRAST_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_GAMMA_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_GAMMA_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_GAMMA_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_AETARGET_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_AETARGET_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_AETARGET_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_WBGAIN_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_WBGAIN_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_WBGAIN_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BLACKLEVEL_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BLACKLEVEL8_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BLACKLEVEL10_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BLACKLEVEL12_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BLACKLEVEL14_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_BLACKLEVEL16_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_STRENGTH_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_STRENGTH_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_STRENGTH_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_RADIUS_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_RADIUS_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_RADIUS_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_THRESHOLD_DEF_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_THRESHOLD_MIN_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    MZCAM_SHARPENING_THRESHOLD_MAX_value = mxCreateDoubleMatrix(1, 1, mxREAL);
    *mxGetPr(MZCAM_TEMP_DEF_value) = static_cast<double>(MZCAM_TEMP_DEF);
    *mxGetPr(MZCAM_TEMP_MIN_value) = static_cast<double>(MZCAM_TEMP_MIN);
    *mxGetPr(MZCAM_TEMP_MAX_value) = static_cast<double>(MZCAM_TEMP_MAX);
    *mxGetPr(MZCAM_TINT_DEF_value) = static_cast<double>( MZCAM_TINT_DEF);
    *mxGetPr(MZCAM_TINT_MIN_value) = static_cast<double>(MZCAM_TINT_MIN);
    *mxGetPr(MZCAM_TINT_MAX_value) = static_cast<double>(MZCAM_TINT_MAX);
    *mxGetPr(MZCAM_HUE_DEF_value) = static_cast<double>(MZCAM_HUE_DEF);
    *mxGetPr(MZCAM_HUE_MIN_value) = static_cast<double>(MZCAM_HUE_MIN);
    *mxGetPr(MZCAM_HUE_MAX_value) = static_cast<double>(MZCAM_HUE_MAX);
    *mxGetPr(MZCAM_SATURATION_DEF_value) = static_cast<double>(MZCAM_SATURATION_DEF);
    *mxGetPr(MZCAM_SATURATION_MIN_value) = static_cast<double>(MZCAM_SATURATION_MIN);
    *mxGetPr(MZCAM_SATURATION_MAX_value) = static_cast<double>(MZCAM_SATURATION_MAX);
    *mxGetPr(MZCAM_BRIGHTNESS_DEF_value) = static_cast<double>(MZCAM_BRIGHTNESS_DEF);
    *mxGetPr(MZCAM_BRIGHTNESS_MIN_value) = static_cast<double>(MZCAM_BRIGHTNESS_MIN);
    *mxGetPr(MZCAM_BRIGHTNESS_MAX_value) = static_cast<double>(MZCAM_BRIGHTNESS_MAX);
    *mxGetPr(MZCAM_CONTRAST_DEF_value) = static_cast<double>(MZCAM_CONTRAST_DEF);
    *mxGetPr(MZCAM_CONTRAST_MIN_value) = static_cast<double>(MZCAM_CONTRAST_MIN);
    *mxGetPr(MZCAM_CONTRAST_MAX_value) = static_cast<double>(MZCAM_CONTRAST_MAX);
    *mxGetPr(MZCAM_GAMMA_DEF_value) = static_cast<double>(MZCAM_GAMMA_DEF);
    *mxGetPr(MZCAM_GAMMA_MIN_value) = static_cast<double>(MZCAM_GAMMA_MIN);
    *mxGetPr(MZCAM_GAMMA_MAX_value) = static_cast<double>(MZCAM_GAMMA_MAX);
    *mxGetPr(MZCAM_AETARGET_DEF_value) = static_cast<double>(MZCAM_AETARGET_DEF);
    *mxGetPr(MZCAM_AETARGET_MIN_value) = static_cast<double>(MZCAM_AETARGET_MIN);
    *mxGetPr(MZCAM_AETARGET_MAX_value) = static_cast<double>(MZCAM_AETARGET_MAX);
    *mxGetPr(MZCAM_WBGAIN_DEF_value) = static_cast<double>(MZCAM_WBGAIN_DEF);
    *mxGetPr(MZCAM_WBGAIN_MIN_value) = static_cast<double>(MZCAM_WBGAIN_MIN);
    *mxGetPr(MZCAM_WBGAIN_MAX_value) = static_cast<double>(MZCAM_WBGAIN_MAX);
    *mxGetPr(MZCAM_BLACKLEVEL_MIN_value) = static_cast<double>(MZCAM_BLACKLEVEL_MIN );
    *mxGetPr(MZCAM_BLACKLEVEL8_MAX_value) = static_cast<double>( MZCAM_BLACKLEVEL8_MAX);
    *mxGetPr(MZCAM_BLACKLEVEL10_MAX_value) = static_cast<double>(MZCAM_BLACKLEVEL10_MAX);
    *mxGetPr(MZCAM_BLACKLEVEL12_MAX_value) = static_cast<double>(MZCAM_BLACKLEVEL12_MAX);
    *mxGetPr(MZCAM_BLACKLEVEL14_MAX_value) = static_cast<double>(MZCAM_BLACKLEVEL14_MAX);
    *mxGetPr(MZCAM_BLACKLEVEL16_MAX_value) = static_cast<double>(MZCAM_BLACKLEVEL16_MAX);
    *mxGetPr(MZCAM_SHARPENING_STRENGTH_DEF_value) = static_cast<double>(MZCAM_SHARPENING_STRENGTH_DEF);
    *mxGetPr(MZCAM_SHARPENING_STRENGTH_MIN_value) = static_cast<double>(MZCAM_SHARPENING_STRENGTH_MIN);
    *mxGetPr(MZCAM_SHARPENING_STRENGTH_MAX_value) = static_cast<double>(MZCAM_SHARPENING_STRENGTH_MAX);
    *mxGetPr(MZCAM_SHARPENING_RADIUS_DEF_value) = static_cast<double>(MZCAM_SHARPENING_RADIUS_DEF);
    *mxGetPr(MZCAM_SHARPENING_RADIUS_MIN_value) = static_cast<double>(MZCAM_SHARPENING_RADIUS_MIN);
    *mxGetPr(MZCAM_SHARPENING_RADIUS_MAX_value) = static_cast<double>(MZCAM_SHARPENING_RADIUS_MAX);
    *mxGetPr(MZCAM_SHARPENING_THRESHOLD_DEF_value) = static_cast<double>(MZCAM_SHARPENING_THRESHOLD_DEF);
    *mxGetPr(MZCAM_SHARPENING_THRESHOLD_MIN_value) = static_cast<double>(MZCAM_SHARPENING_THRESHOLD_MIN);
    *mxGetPr(MZCAM_SHARPENING_THRESHOLD_MAX_value) = static_cast<double>(MZCAM_SHARPENING_THRESHOLD_MAX);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_TEMP_DEF_field, MZCAM_TEMP_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_TEMP_MIN_field, MZCAM_TEMP_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_TEMP_MAX_field, MZCAM_TEMP_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_TINT_DEF_field, MZCAM_TINT_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_TINT_MIN_field, MZCAM_TINT_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_TINT_MAX_field, MZCAM_TINT_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_HUE_DEF_field, MZCAM_HUE_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_HUE_MIN_field, MZCAM_HUE_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_HUE_MAX_field, MZCAM_HUE_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SATURATION_DEF_field, MZCAM_SATURATION_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SATURATION_MIN_field, MZCAM_SATURATION_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SATURATION_MAX_field, MZCAM_SATURATION_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BRIGHTNESS_DEF_field, MZCAM_BRIGHTNESS_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BRIGHTNESS_MIN_field, MZCAM_BRIGHTNESS_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BRIGHTNESS_MAX_field, MZCAM_BRIGHTNESS_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_CONTRAST_DEF_field, MZCAM_CONTRAST_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_CONTRAST_MIN_field, MZCAM_CONTRAST_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_CONTRAST_MAX_field, MZCAM_CONTRAST_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_GAMMA_DEF_field, MZCAM_GAMMA_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_GAMMA_MIN_field, MZCAM_GAMMA_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_GAMMA_MAX_field, MZCAM_GAMMA_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_AETARGET_DEF_field, MZCAM_AETARGET_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_AETARGET_MIN_field, MZCAM_AETARGET_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_AETARGET_MAX_field, MZCAM_AETARGET_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_WBGAIN_DEF_field, MZCAM_WBGAIN_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_WBGAIN_MIN_field, MZCAM_WBGAIN_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_WBGAIN_MAX_field, MZCAM_WBGAIN_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BLACKLEVEL_MIN_field, MZCAM_BLACKLEVEL_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BLACKLEVEL8_MAX_field, MZCAM_BLACKLEVEL8_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BLACKLEVEL10_MAX_field, MZCAM_BLACKLEVEL10_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BLACKLEVEL12_MAX_field, MZCAM_BLACKLEVEL12_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BLACKLEVEL14_MAX_field, MZCAM_BLACKLEVEL14_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_BLACKLEVEL16_MAX_field, MZCAM_BLACKLEVEL16_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_STRENGTH_DEF_field, MZCAM_SHARPENING_STRENGTH_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_STRENGTH_MIN_field, MZCAM_SHARPENING_STRENGTH_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_STRENGTH_MAX_field, MZCAM_SHARPENING_STRENGTH_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_RADIUS_DEF_field, MZCAM_SHARPENING_RADIUS_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_RADIUS_MIN_field, MZCAM_SHARPENING_RADIUS_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_RADIUS_MAX_field, MZCAM_SHARPENING_RADIUS_MAX_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_THRESHOLD_DEF_field, MZCAM_SHARPENING_THRESHOLD_DEF_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_THRESHOLD_MIN_field, MZCAM_SHARPENING_THRESHOLD_MIN_value);
    mxSetFieldByNumber(plhs[3], 0, MZCAM_SHARPENING_THRESHOLD_MAX_field, MZCAM_SHARPENING_THRESHOLD_MAX_value);
}

void mexFunction(int nlhs, mxArray* plhs[], int nrhs, const mxArray* prhs[])
{
    if (nrhs == 0)
        EnumCameras(plhs);
    else if (nrhs == 4)
    {
        unsigned nRes = static_cast<unsigned>(*(mxGetPr(prhs[0])));
        unsigned short nSpeed = static_cast<unsigned short>(*(mxGetPr(prhs[1])));
        char ID[64] = { 0 };
        mxGetString(prhs[2], ID, sizeof(ID));
        if (S_OK == Init(nRes, nSpeed, ID))
        {
            int srcW = 0, srcH = 0;
            Mzcam_get_Resolution(g_hCam, 0, &srcW, &srcH);
            mwSize dims[2] = {srcW * 3, srcH};
            plhs[0] = mxCreateNumericArray(2, dims, mxUINT8_CLASS, mxREAL);
            g_imgData = static_cast<unsigned char*>(mxGetData(plhs[0]));
            mexMakeMemoryPersistent(g_imgData);
            plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
            plhs[2] = mxCreateDoubleMatrix(1, 1, mxREAL);
            double* w = mxGetPr(plhs[1]);
            double* h = mxGetPr(plhs[2]);
            *w = static_cast<double>(srcW);
            *h = static_cast<double>(srcH);
            ConstParams(plhs);
        }
    }
    else if (nrhs == 2)
    {
        if (nullptr == g_hCam)
            return;
        const int value = static_cast<int>(*mxGetPr(prhs[1]));
        switch (static_cast<int>(*mxGetPr(prhs[0])))
        {
            case PARAM_CLOSE:
                Mzcam_Close(g_hCam);
                g_hCam = nullptr;
                break;
            case PARAM_SNAP:
                Mzcam_Snap(g_hCam, 0);
                break;
            case PARAM_AEXP:
                {
                    BOOL bAutoExposure;
                    unsigned nTime;
                    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
                    plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
                    double* y = mxGetPr(plhs[0]);
                    double* time = mxGetPr(plhs[1]);
                    Mzcam_get_AutoExpoEnable(g_hCam, &bAutoExposure);
                    Mzcam_put_AutoExpoEnable(g_hCam, !bAutoExposure);
                    Mzcam_get_ExpoTime(g_hCam, &nTime);
                    *y = !bAutoExposure;
                    *time = nTime;
                }
                break;
            case PARAM_EXPTIME:
                Mzcam_put_ExpoTime(g_hCam, static_cast<unsigned>(value));
                break;
            case PARAM_WBONCE:
                {
                    int nTemp, nTint;
                    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
                    plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
                    double* temp = mxGetPr(plhs[0]);
                    double* tint = mxGetPr(plhs[1]);
                    Mzcam_AwbOnce(g_hCam, nullptr, nullptr);
                    Mzcam_get_TempTint(g_hCam, &nTemp, &nTint);
                    *temp = (double)nTemp;
                    *tint = (double)nTint;
                }
                break;
            case PARAM_TEMP:
                {
                    int nTemp = 0, nTint = 0;
                    Mzcam_get_TempTint(g_hCam, &nTemp, &nTint);
                    Mzcam_put_TempTint(g_hCam, value, nTint);
                }
                break;
            case PARAM_TINT:
                {
                    int nTemp = 0, nTint = 0;
                    Mzcam_get_TempTint(g_hCam, &nTemp, &nTint);
                    Mzcam_put_TempTint(g_hCam, nTemp, value);
                }
                break;
            case PARAM_HUE:
                Mzcam_put_Hue(g_hCam, value);
                break;
            case PARAM_SATURATION:
                Mzcam_put_Saturation(g_hCam, value);
                break;
            case PARAM_BRIGHTNESS:
                Mzcam_put_Brightness(g_hCam, value);
                break;
            case PARAM_CONTRAST:
                Mzcam_put_Contrast(g_hCam, value);
                break;
            case PARAM_GAMMA:
                Mzcam_put_Gamma(g_hCam, value);
                break;
            case PARAM_WBDFT:
                Mzcam_put_TempTint(g_hCam, MZCAM_TEMP_DEF, MZCAM_TINT_DEF);
                break;
            case PARAM_COLORDFT:
                Mzcam_put_Hue(g_hCam, MZCAM_HUE_DEF);
                Mzcam_put_Saturation(g_hCam, MZCAM_SATURATION_DEF);
                Mzcam_put_Brightness(g_hCam, MZCAM_BRIGHTNESS_DEF);
                Mzcam_put_Contrast(g_hCam, MZCAM_CONTRAST_DEF);
                Mzcam_put_Gamma(g_hCam, MZCAM_GAMMA_DEF);
                break;
            case PARAM_BBONCE:
                {
                    unsigned short aSub[3] = { 0 };
                    Mzcam_AbbOnce(g_hCam, nullptr, nullptr);
                    Mzcam_get_BlackBalance(g_hCam, aSub);
                    plhs[0] = mxCreateDoubleMatrix(1, 3, mxREAL);
                    double* plaSub = mxGetPr(plhs[0]);
                    plaSub[0] = aSub[0];
                    plaSub[1] = aSub[1];
                    plaSub[2] = aSub[2];
                }
                break;
            case PARAM_ROFFSET:
                {
                    unsigned short aSub[3] = { 0 };
                    Mzcam_get_BlackBalance(g_hCam, aSub);
                    aSub[0] = value;
                    Mzcam_put_BlackBalance(g_hCam, aSub);
                    Mzcam_get_BlackBalance(g_hCam, aSub);
                }
                break;
            case PARAM_GOFFSET:
                {
                    unsigned short aSub[3] = { 0 };
                    Mzcam_get_BlackBalance(g_hCam, aSub);
                    aSub[1] = value;
                    Mzcam_put_BlackBalance(g_hCam, aSub);
                }
                break;
            case PARAM_BOFFSET:
                {
                    unsigned short aSub[3] = { 0 };
                    Mzcam_get_BlackBalance(g_hCam, aSub);
                    aSub[2] = value;
                    Mzcam_put_BlackBalance(g_hCam, aSub);
                }
                break;
            case PARAM_BBDFT:
                {
                    unsigned short aSub[3] = { 0 };
                    Mzcam_put_BlackBalance(g_hCam, aSub);
                }
                break;
            case PARAM_CHROME:
                Mzcam_put_Chrome(g_hCam, value);
                break;
            case PARAM_FFCONCE:
                Mzcam_FfcOnce(g_hCam);
                break;
            case PARAM_DFCONCE:
                Mzcam_DfcOnce(g_hCam);
                break;
            case PARAM_POWERSUPPLY:
                Mzcam_put_HZ(g_hCam, value);
                break;
            case PARAM_VFLIP:
                {
                    int bVFlip = 0;
                    Mzcam_get_VFlip(g_hCam, &bVFlip);  /* vertical flip */
                    Mzcam_put_VFlip(g_hCam, !bVFlip);
                }
                break;
            case PARAM_HFLIP:
                {
                    int bHFlip = 0;
                    Mzcam_get_HFlip(g_hCam, &bHFlip);  /* vertical flip */
                    Mzcam_put_HFlip(g_hCam, !bHFlip);
                }
                break;
            case PARAM_ROTATE:
                {
                    int iValue = 0;
                    Mzcam_get_Option(g_hCam, MZCAM_OPTION_ROTATE, &iValue);
                    iValue = 180 - iValue;
                    Mzcam_put_Option(g_hCam, MZCAM_OPTION_ROTATE, iValue);
                }
                break;
            case PARAM_SHARPENING:
                Mzcam_put_Option(g_hCam, MZCAM_OPTION_SHARPENING, value);
                break;
            case PARAM_BITDEPTH:
                Mzcam_put_Option(g_hCam, MZCAM_OPTION_BITDEPTH, value);
                break;
            case PARAM_BINNING:
                Mzcam_put_Option(g_hCam, MZCAM_OPTION_BINNING, value);
                break;
            case PARAM_LINEAR:
                Mzcam_put_Option(g_hCam, MZCAM_OPTION_LINEAR, value);
                break;
            case PARAM_CURVE:
                Mzcam_put_Option(g_hCam, MZCAM_OPTION_CURVE, value);
                break;
            default:
                break;
        }
    }
    else
    {
        mexErrMsgIdAndTxt("MATLAB:mexFun:InvalidInput", "Invalid Input.");
    }
}
